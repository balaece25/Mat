Jasmine Snippets for Sublime Text 2
======

that's all.
